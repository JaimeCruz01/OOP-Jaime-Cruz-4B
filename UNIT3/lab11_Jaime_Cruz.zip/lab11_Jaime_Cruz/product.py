from main import ProductoNoEncontrado, CantidadInvalida, StockInsuficiente
class Product:
    def __init__(self, codigo, stock):
        self.codigo = codigo
        self.stock = stock

    def retirar(self, cantidad):

        if cantidad <= 0:
            raise CantidadInvalida(
                "La cantidad a retirar debe ser un número positivo."
            )

        if self.stock < cantidad:
            raise StockInsuficiente(
                f"Stock insuficiente. Disponible: {self.stock}, solicitado: {cantidad}."
            )

        self.stock -= cantidad