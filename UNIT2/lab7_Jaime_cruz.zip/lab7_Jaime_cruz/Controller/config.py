DB_config = {
    'host': 'localhost',
    'user': 'postgres',
    'password': 'jaime1305',
    'dbname': 'login_system_db',
    'port': 5432
}